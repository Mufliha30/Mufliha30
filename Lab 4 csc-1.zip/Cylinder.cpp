﻿#include "Cylinder.h"
#include <cmath> // for M_PI
#include <iostream>
using namespace std;

Cylinder::Cylinder(float r, float h) : Circle(r) {
    setHeight(h);
}

void Cylinder::setHeight(float h) {
    if (h >= 0) {
        height = h;
    }
    else {
        cout << "Height must be zero or greater. Setting to 0 by default." << endl;
        height = 0;
    }
}

float Cylinder::getHeight() const {
    return height;
}

float Cylinder::getSurfaceArea() const {
    float baseArea = M_PI * getRadius() * getRadius(); // π * r^2
    float lateralSurfaceArea = 2 * M_PI * getRadius() * height; // 2πrh
    return 2 * baseArea + lateralSurfaceArea; // Total surface area
}

float Cylinder::getVolume() const {
    return M_PI * getRadius() * getRadius() * height; // πr^2h
}


