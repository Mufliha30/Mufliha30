#include "Circle.h"
#include "Cylinder.h"
#include <iostream>
#include <iomanip> // for fixed and setprecision
using namespace std;

int main() {
    float radius, height;

    cout << "Cylinder App!" << endl;
    cout << "---------------------" << endl;

    // Prompt user for radius
    cout << "Enter radius: ";
    cout << "\033[31m"; // Switch to red text
    cin >> radius;
    cout << "\033[0m";  // Reset text color

    // Prompt user for height
    cout << "Enter height: ";
    cout << "\033[31m"; // Switch to red text
    cin >> height;
    cout << "\033[0m";  // Reset text color

    // Create a Cylinder object
    Cylinder cylinder(radius, height);

    // Display the results
    cout << fixed << setprecision(3);
    cout << "Cylinder area: " << cylinder.getSurfaceArea() << endl;
    cout << "Cylinder volume: " << cylinder.getVolume() << endl;

    // Final message with "red" in red color
    cout << "\nUser input is in \033[31mred\033[0m" << endl;

    return 0;
}



