#include "Circle.h"
#include <iostream>
using namespace std;

Circle::Circle(float r) {
    setRadius(r);
}

void Circle::setRadius(float r) {
    if (r >= 0) {
        radius = r;
    }
    else {
        cout << "Radius must be zero or greater. Setting to 0 by default." << endl;
        radius = 0;
    }
}

float Circle::getRadius() const {
    return radius;
}

float Circle::getPerimeter() const {
    return 2 * M_PI * radius;
}

float Circle::getArea() const {
    return M_PI * radius * radius;
}

