#ifndef CYLINDER_H
#define CYLINDER_H

#include "Circle.h"

class Cylinder : public Circle {
private:
    float height;

public:
    Cylinder(float r = 0, float h = 0);
    void setHeight(float h);
    float getHeight() const;
    float getSurfaceArea() const;
    float getVolume() const;
};

#endif // CYLINDER_H


