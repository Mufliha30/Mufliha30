#ifndef CIRCLE_H
#define CIRCLE_H

#define _USE_MATH_DEFINES
#include <cmath>

class Circle {
private:
    float radius;

public:
    Circle(float r = 0);
    void setRadius(float r);
    float getRadius() const;
    float getPerimeter() const;
    float getArea() const;
};

#endif // CIRCLE_H

